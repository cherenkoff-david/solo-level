const supabase = require('./supabaseClient');

module.exports = supabase;

